/*===============================================================
*   Copyright (C) 2019 All rights reserved.
*   
*   文件名称：str.c
*   创 建 者：pengtangtang
*   创建日期：2019年10月01日
*   描    述：
*
*   更新日志：
*
================================================================*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <strings.h>
char * get_memory(char **p,int n)
{
	*p = (char *)malloc(n);
}
void main()
{
	char *str = NULL;
	 get_memory(&str,100);
	strcpy(str,"hello");
	printf("%s\n",str);
}
